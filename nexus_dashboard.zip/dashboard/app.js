document.addEventListener('DOMContentLoaded', async () => {
    // Interactive Mouse Glow (Apple Effect)
    document.body.addEventListener('mousemove', (e) => {
        document.documentElement.style.setProperty('--mouse-x', `${e.clientX}px`);
        document.documentElement.style.setProperty('--mouse-y', `${e.clientY}px`);
    });

    // Elements
    const listEl = document.getElementById('roles-list');
    const statTotal = document.getElementById('stat-total');
    const statAvgCtc = document.getElementById('stat-avg-ctc');
    const searchInput = document.getElementById('search-input');
    const ctcSlider = document.getElementById('ctc-slider');
    const ctcVal = document.getElementById('ctc-val');
    
    // Modal
    const modal = document.getElementById('job-modal');
    const closeModal = document.getElementById('close-modal');
    
    // State
    let allRoles = [];
    let hiddenRolesMap = {};
    let roleNotesMap = {};
    let roleStatusMap = {}; 
    let currentView = 'all'; 
    let minCtc = 0;
    let searchQuery = '';

    // Load Data
    const data = await chrome.storage.local.get(['allRoles', 'hiddenRoles', 'roleNotes', 'roleStatus']);
    allRoles = data.allRoles || [];
    
    // Build maps
    const hRoles = data.hiddenRoles || [];
    hRoles.forEach(r => hiddenRolesMap[r.posting_id] = true);
    roleNotesMap = data.roleNotes || {};
    roleStatusMap = data.roleStatus || {};

    // Initial Processing
    allRoles.forEach(role => {
        if (!roleStatusMap[role.posting_id] && role.registered && role.registered.toUpperCase() === 'YES') {
            roleStatusMap[role.posting_id] = 'applied';
        } else if (!roleStatusMap[role.posting_id]) {
            roleStatusMap[role.posting_id] = 'to_apply';
        }
    });

    renderList();
    renderCalendar();

    // Nav Listeners
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            item.classList.add('active');
            currentView = item.dataset.view;
            
            const titles = {
                'all': 'All Open Roles',
                'applied': 'Applied Pipeline',
                'urgent': 'Urgent Deadlines',
                'hidden': 'Hidden Archive'
            };
            document.getElementById('view-title').textContent = titles[currentView];
            renderList();
        });
    });

    // Filters
    searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.toLowerCase();
        renderList();
    });

    ctcSlider.addEventListener('input', (e) => {
        minCtc = parseInt(e.target.value);
        ctcVal.textContent = minCtc;
        renderList();
    });

    closeModal.addEventListener('click', () => modal.classList.remove('active'));

    function renderList() {
        listEl.innerHTML = '';
        
        let filteredRoles = allRoles.filter(role => {
            const isHidden = hiddenRolesMap[role.posting_id];
            if (currentView === 'hidden' && !isHidden) return false;
            if (currentView !== 'hidden' && isHidden) return false;

            const status = roleStatusMap[role.posting_id];
            if (currentView === 'applied' && status !== 'applied' && status !== 'interviewing' && status !== 'offer') return false;
            
            const hoursLeft = getHoursLeft(role.deadline);
            if (currentView === 'urgent' && (hoursLeft < 0 || hoursLeft > 24 || status === 'applied' || status === 'offer')) return false;

            if (searchQuery) {
                const text = (role.company + ' ' + role.title).toLowerCase();
                if (!text.includes(searchQuery)) return false;
            }

            const ctcNum = extractCtcNumber(role.ctc);
            if (ctcNum < minCtc) return false;

            return true;
        });

        filteredRoles.sort((a, b) => {
            const ha = getHoursLeft(a.deadline);
            const hb = getHoursLeft(b.deadline);
            if (ha < 0 && hb > 0) return 1;
            if (hb < 0 && ha > 0) return -1;
            return ha - hb;
        });

        updateStats(filteredRoles);

        if (filteredRoles.length === 0) {
            listEl.innerHTML = '<div style="color: var(--text-muted); text-align: center; padding: 40px; font-size: 14px;">No roles found in this view.</div>';
            return;
        }

        filteredRoles.forEach(role => {
            const row = document.createElement('div');
            row.className = 'list-row';
            
            const hoursLeft = getHoursLeft(role.deadline);
            const status = roleStatusMap[role.posting_id];
            
            let statusBadge = '<span class="badge b-normal">To Apply</span>';
            if (status === 'applied') statusBadge = '<span class="badge b-applied">Applied</span>';
            if (status === 'interviewing') statusBadge = '<span class="badge" style="background: rgba(255, 204, 0, 0.2); color: #ffcc00;">Interviewing</span>';
            if (status === 'offer') statusBadge = '<span class="badge" style="background: rgba(52, 199, 89, 0.3); color: #fff;">Offer 🎉</span>';
            if (status === 'rejected') statusBadge = '<span class="badge" style="background: rgba(255, 59, 48, 0.2); color: #ff3b30;">Rejected</span>';

            let dlColor = 'inherit';
            let dlIcon = '';
            if (hoursLeft > 0 && hoursLeft < 24 && status === 'to_apply') {
                dlColor = 'var(--danger)';
                dlIcon = '<i class="fa-solid fa-fire" style="margin-right: 4px;"></i>';
            } else if (hoursLeft < 0) {
                dlColor = 'var(--text-muted)';
            }

            row.innerHTML = `
                <div class="col col-company">${escapeHtml(role.company)}</div>
                <div class="col col-role">${escapeHtml(role.title)}</div>
                <div class="col col-ctc">${escapeHtml(role.ctc) || '-'}</div>
                <div class="col col-status">${statusBadge}</div>
                <div class="col col-deadline" style="color: ${dlColor}">${dlIcon}${escapeHtml(role.deadline)}</div>
            `;

            row.addEventListener('click', () => openModal(role));
            listEl.appendChild(row);
        });
    }

    let activeModalRole = null;
    function openModal(role) {
        activeModalRole = role;
        document.getElementById('m-company').textContent = role.company;
        document.getElementById('m-title').textContent = role.title;
        document.getElementById('m-ctc').textContent = role.ctc || 'Not Disclosed';
        document.getElementById('m-deadline').innerHTML = `<i class="fa-regular fa-clock"></i> ${role.deadline}`;
        
        document.getElementById('m-notes-input').value = roleNotesMap[role.posting_id] || '';
        document.getElementById('m-status-select').value = roleStatusMap[role.posting_id] || 'to_apply';

        const btnHide = document.getElementById('m-btn-hide');
        if (hiddenRolesMap[role.posting_id]) {
            btnHide.textContent = 'Unarchive Role';
            btnHide.classList.remove('is-hidden');
            btnHide.style.color = '#fff';
            btnHide.style.borderColor = 'var(--success)';
        } else {
            btnHide.textContent = 'Archive Role';
            btnHide.classList.add('is-hidden');
            btnHide.style = '';
        }

        modal.classList.add('active');
    }

    // Modal Actions
    document.getElementById('m-notes-input').addEventListener('input', (e) => {
        if (!activeModalRole) return;
        roleNotesMap[activeModalRole.posting_id] = e.target.value;
        chrome.storage.local.set({ roleNotes: roleNotesMap });
    });

    document.getElementById('m-status-select').addEventListener('change', (e) => {
        if (!activeModalRole) return;
        roleStatusMap[activeModalRole.posting_id] = e.target.value;
        chrome.storage.local.set({ roleStatus: roleStatusMap });
        renderList();
    });

    document.getElementById('m-btn-hide').addEventListener('click', () => {
        if (!activeModalRole) return;
        const pid = activeModalRole.posting_id;
        if (hiddenRolesMap[pid]) {
            delete hiddenRolesMap[pid];
            const hRoles = data.hiddenRoles || [];
            chrome.storage.local.set({ hiddenRoles: hRoles.filter(r => r.posting_id !== pid) });
        } else {
            hiddenRolesMap[pid] = true;
            const hRoles = data.hiddenRoles || [];
            hRoles.push({ posting_id: pid, company: activeModalRole.company, title: activeModalRole.title, hiddenAt: Date.now() });
            chrome.storage.local.set({ hiddenRoles: hRoles });
        }
        modal.classList.remove('active');
        renderList();
    });

    document.getElementById('m-btn-portal').addEventListener('click', () => {
        if (activeModalRole && activeModalRole.role_url) {
            chrome.tabs.create({ url: activeModalRole.role_url });
        } else {
            alert('URL unavailable. Please check the portal manually.');
        }
    });

    // Calendar Generation
    function renderCalendar() {
        const calGrid = document.querySelector('.calendar-grid');
        
        // Remove old days (keep headers)
        Array.from(calGrid.children).forEach(child => {
            if (!child.classList.contains('cal-day-header')) child.remove();
        });

        // Count deadlines per day
        const deadlineCounts = {}; // format "YYYY-MM-DD": count
        allRoles.forEach(role => {
            if (!role.deadline) return;
            // OCS Format: "5 Oct 2026, 23:59"
            const d = new Date(role.deadline.replace(',', ''));
            if (!isNaN(d)) {
                // Ensure padding for MM and DD
                const dateStr = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
                deadlineCounts[dateStr] = (deadlineCounts[dateStr] || 0) + 1;
            }
        });

        const today = new Date();
        const year = today.getFullYear();
        const month = today.getMonth(); // 0-11
        
        document.getElementById('cal-month').textContent = today.toLocaleString('default', { month: 'short', year: 'numeric' });

        const firstDay = new Date(year, month, 1).getDay(); // 0 = Sun
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        // Empty cells before start of month
        for (let i = 0; i < firstDay; i++) {
            const empty = document.createElement('div');
            empty.className = 'cal-day empty';
            calGrid.appendChild(empty);
        }

        // Days
        for (let i = 1; i <= daysInMonth; i++) {
            const dayEl = document.createElement('div');
            dayEl.className = 'cal-day';
            dayEl.textContent = i;
            
            if (i === today.getDate()) dayEl.classList.add('today');

            const dateStr = year + '-' + String(month+1).padStart(2, '0') + '-' + String(i).padStart(2, '0');
            const count = deadlineCounts[dateStr];

            if (count > 0) {
                dayEl.classList.add('has-dl');
                if (count >= 3) dayEl.classList.add('has-dl-high');
                dayEl.title = `${count} deadline(s)`;
            }

            calGrid.appendChild(dayEl);
        }
    }

    // Helpers
    function getHoursLeft(deadlineStr) {
        if (!deadlineStr) return 9999;
        const parsed = new Date(deadlineStr.replace(',', ''));
        if (isNaN(parsed)) return 9999;
        return (parsed - new Date()) / (1000 * 60 * 60);
    }

    function extractCtcNumber(ctcStr) {
        if (!ctcStr) return 0;
        const numStr = ctcStr.replace(/[^0-9]/g, '');
        const rawNum = parseInt(numStr, 10);
        if (isNaN(rawNum)) return 0;
        return rawNum / 100000; 
    }

    function updateStats(roles) {
        statTotal.textContent = roles.length;
        let validCtcCount = 0;
        let sumCtc = 0;
        roles.forEach(r => {
            const ctcNum = extractCtcNumber(r.ctc);
            if (ctcNum > 0) { sumCtc += ctcNum; validCtcCount++; }
        });
        statAvgCtc.textContent = validCtcCount > 0 ? '₹ ' + (sumCtc / validCtcCount).toFixed(1) + 'L' : 'N/A';
    }

    function escapeHtml(unsafe) {
        if (!unsafe) return '';
        return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }
});
